﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Biblioteka
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        string StringKonekcije = (@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=d:\Market.accdb;Persist Security Info=False;");
        OleDbConnection Konekcija;
        OleDbCommand Komanda = new OleDbCommand();

        private void button1_Click(object sender, EventArgs e)
        {
            if (Naziv.Text == "")
            {
                MessageBox.Show("Naziv je obavezan podatak");
                Naziv.Focus();
            }
            else if (Opis.Text == "")
            {
                MessageBox.Show("Opis je obavezan podatak");
                Opis.Focus();
            }
            else if (Kategorija.Text == "")
            {
                MessageBox.Show("Kategorija je obavezan podatak");
                Kategorija.Focus();
            }
            else if (Proizvodjac.Text == "")
            {
                MessageBox.Show("Proizvodjac je obavezan podatak");
                Proizvodjac.Focus();
            }
            else if (Dobavljac.Text == "")
            {
                MessageBox.Show("Dobavljac je obavezan podatak");
                Dobavljac.Focus();
            }
            else if (Cena.Text == "")
            {
                MessageBox.Show("Cena je obavezan podatak");
                Cena.Focus();
            }
            else
            {
                Konekcija = new OleDbConnection(StringKonekcije);
                Konekcija.Open();/*Otvaranje baze podataka*/
                Komanda.Connection = Konekcija;/*Povezivanje komande i konekci*/
                Komanda.CommandType = CommandType.Text;/*Tipa komande*/
                /*formiranje SQL upita komandi*/
                string sqlupit = "UPDATE Proizvod SET Naziv='" + Naziv.Text;
                sqlupit += "', Opis='" + Opis.Text + "', Kategorija='" + Kategorija.Text + "'" +
               ",Proizvodjac = '" + Proizvodjac.Text + "',Dobavljac='" + Dobavljac.Text + "',Cena='" + Cena.Text;
                sqlupit += "' WHERE Id=" + Id.Text;
                Komanda.CommandText = sqlupit;
                int responce = Komanda.ExecuteNonQuery();
                Konekcija.Close();
                this.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Konekcija = new OleDbConnection(StringKonekcije);
            Konekcija.Open();/*Otvaranje baze podataka*/
            Komanda.Connection = Konekcija;/*Povezivanje komande i konekcije*/
            Komanda.CommandType = CommandType.Text;/*Određivanje tipa komande*/
            /*formiranje SQL upita komandi*/
            string sqlupit = "DELETE FROM Proizvod WHERE Id=" + Id.Text;
            Komanda.CommandText = sqlupit;
            int responce = Komanda.ExecuteNonQuery();
            Konekcija.Close();
            this.Close();
        }
    }
}
