﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Biblioteka
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string StringKonekcije = (@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=d:\Market.accdb;Persist Security Info=False;");
        OleDbConnection Konekcija;
        OleDbCommand Komanda = new OleDbCommand();
        OleDbDataReader SetPodataka = null;

        public class Proizvod
        {
            public int Id;
            public string Naziv;
            public string Opis;
            public string Kategorija;
            public string Proizvodjac;
            public string Dobavljac;
            public string Cena;

            public Proizvod(OleDbDataReader SetPodataka)
            {
                this.Id= SetPodataka.GetInt32(0);
                this.Naziv = SetPodataka.GetString(1);
                this.Opis = SetPodataka.GetString(2);
                this.Kategorija = SetPodataka.GetString(3);
                this.Proizvodjac = SetPodataka.GetString(4);
                this.Dobavljac = SetPodataka.GetString(5);
                this.Cena = SetPodataka.GetString(6);
            }

            public override string ToString()
            {
                return Naziv + " " + Opis + " " + Kategorija + " " + Proizvodjac + " " + Dobavljac + " " + Cena;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            {
                ucitaj();
            }
        }
        private void ucitaj()
        {
            Lista.Items.Clear();
            Konekcija = new OleDbConnection(StringKonekcije);
            Konekcija.Open();
            Komanda.Connection = Konekcija;
            Komanda.CommandType = CommandType.Text;
            string sqlupit = "SELECT * FROM Proizvod";
            Komanda.CommandText = sqlupit;
            SetPodataka = Komanda.ExecuteReader();

            Proizvod Proizvod1;
            while (SetPodataka.Read())
            {
                Proizvod1 = new Proizvod(SetPodataka);
                Lista.Items.Add(Proizvod1);
            }
            SetPodataka.Close();
            Konekcija.Close();
        }

       

        private void unosProizvodaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 frm = new Form2();
            frm.Show();
        }

        

        private void button3_Click(object sender, EventArgs e)
        {
            if (Lista.SelectedIndex >= 0)
            {
                Form3 frm = new Form3();
                Proizvod Proizvod1 = (Proizvod)Lista.Items[Lista.SelectedIndex];
                frm.Id.Text = Proizvod1.Id.ToString();
                frm.Naziv.Text = Proizvod1.Naziv;
                frm.Opis.Text = Proizvod1.Opis;
                frm.Kategorija.Text = Proizvod1.Kategorija;
                frm.Proizvodjac.Text = Proizvod1.Proizvodjac;
                frm.Dobavljac.Text = Proizvod1.Dobavljac;
                frm.Cena.Text = Proizvod1.Cena;
                frm.ShowDialog();
                ucitaj();
            }
        }
    }
}
